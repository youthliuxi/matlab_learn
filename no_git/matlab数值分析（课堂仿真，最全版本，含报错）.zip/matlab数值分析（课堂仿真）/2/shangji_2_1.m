clc
clear all
A=[0.5 1.1 3.1;2 4.5 3.6;5 0.96 6.5];
b=[6;0.02;0.969];
x=Pivot_Gauss(A,b)