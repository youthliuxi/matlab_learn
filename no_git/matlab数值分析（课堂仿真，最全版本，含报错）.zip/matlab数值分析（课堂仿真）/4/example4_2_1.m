% Example4_2_1.m
X=[0.25 0.30 0.39 0.45 0.53];
Y=[0.5000 0.5477 0.6245 0.6708 0.7280];
a=0.43;
[L,p,b]=Lagrange_Interpolation(X,Y,a)