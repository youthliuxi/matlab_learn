clc
clear all
A=[1 2 -1;-3 1 2;3 -2 1];
b=[1;2;3];
%x=Pivot_Gauss(A,b)
x=A\b