% Example4_3_1.m
X=[1.0 1.3 1.8 2.5 3.0];
Y=[1.000 2.197 5.832 15.625 27.000];
a=2.00;
[f,b]=Newton_Interpolation(X,Y,a)