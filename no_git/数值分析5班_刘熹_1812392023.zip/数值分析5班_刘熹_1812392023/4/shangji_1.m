% �ϻ���1.m
X=[-2 0 1 2];
Y=[7.00 1.00 2.00 8.00];
a=0.4;
[L,p,b]= Lagrange_Interpolation(X,Y,a)